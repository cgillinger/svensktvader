Changelog - Svenskt Väder 1.0.1
Nya funktioner

Förbättrad fyradagarsprognos - Fyradagarsprognosen visar nu tydligare min- och maxtemperaturer för varje dag samt dominerande väderförhållanden med förbättrad ikonvisning.

Buggfixar

Korrigerad beräkning av vindriktning för att korrekt visa varifrån vinden kommer
Fixade layoutproblem i den kompakta detaljpanelen på mindre skärmar
Åtgärdade problem med att hämta lufttrycksdata från vissa väderstationer
Förbättrad cachningslogik för soluppgång/solnedgång för att minska datamängden
Korrigerade språkfel i vissa väderbeskrivningar
Korrigerade fel i tryckmätningen

Underhåll

Mindre kodoptimering för snabbare laddning
Uppdaterad dokumentation

Tack till alla som rapporterat buggar och kommit med förbättringsförslag!